# globals called g
# Students should maintain the folloing globals for the remaing code to work:
# generation, mutations, best, bestScore, MUTATIONPERCENT, POPULATION

NUM_OF_TRUCKS = 3
NUM_OF_ITEMS = 30
TRUCK_CAPACITY = 19

POPULATION = 100;
MUTATIONPERCENT=3 

generation=0;  # Current generation
maxGeneration =20;
marker = -99999; # marker used by me to indicate a special condition (i dont think students will need it) 
mutations = 0; # number of mutations
best = 0; # the nunber in the Population of the best individual 
bestScore = -99991 # the score of the best individual
